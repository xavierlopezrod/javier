export interface ILastThankYou {
  version: string
  checkedUsers: ReadonlyArray<string>
}
