export type EndpointToken = { endpoint: string; token: string }
